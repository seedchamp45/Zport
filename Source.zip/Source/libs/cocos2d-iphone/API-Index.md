This is the Cocos2D-Swift Objective-C Class Reference.<br/>
To learn Cocos2D/SpriteBuilder please read the [**Developer Guide**](http://makegameswith.us/docs/).
